This is a demo app which shows the usage of the class CFavoriteEngine. 
This class is a free class. You can use it in any way you want. 
BUT NOTE:
 This software is provided "as is" without express or implied warranty. 
 Use it at you own risk! The author accepts no liability for any damages 
 to your computer or data these products may cause.
